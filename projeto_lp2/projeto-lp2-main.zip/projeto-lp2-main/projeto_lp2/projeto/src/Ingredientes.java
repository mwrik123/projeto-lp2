public enum Ingredientes{
    HAMB,
    PAO,
    SALADA,
    MOLHO,
    OVO,
    QUEIJO,
    CARNE,
    FRANGO,
    SALSICHA,
    HAMB2,
    HAMB3,
    SALADA2
}